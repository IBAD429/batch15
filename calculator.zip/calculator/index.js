// import { add } from './modules/add.js';
// import { subtract } from './modules/subtract.js';
// import { multiply } from './modules/multiply.js';
// import { divide } from './modules/divide.js';

// // Example usage
// console.log("Add: ", add(10, 5));
// console.log("Subtract: ", subtract(10, 5));
// console.log("Multiply: ", multiply(10, 5));
// console.log("Divide: ", divide(10, 5));
// console.log("Divide by 0: ", divide(10, 0));

const {sum , multiply , divide , subtract} = require('./math.js');

let sumAnswer = sum(7 , 4);
console.log(sumAnswer)

let subAnswer = subtract(3, 2);
console.log(subAnswer);

let multiplyAnswer = multiply(6 , 9);
console.log(multiplyAnswer);

let divAnswer = divide(10 , 2);
console.log(divAnswer)
